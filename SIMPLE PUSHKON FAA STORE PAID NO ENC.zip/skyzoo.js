module.exports = async (Skyzo, m, store) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '' //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await Skyzo.decodeJid(Skyzo.user.id)
const isOwner = m.sender == owner+"@s.whatsapp.net" ? true : m.sender == botNumber ? true : false
const isGroup = m.chat.endsWith('@g.us')
const senderNumber = m.sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await Skyzo.groupMetadata(m.key.remoteJid) : {}
let participant_bot = (isGroup ? groupMetadata.participants.find((v) => v.id == m.botNumber) : {}) || {}
let participant_sender = (isGroup ? groupMetadata.participants.find((v) => v.id == m.sender) : {}) || {}
const isBotAdmin = participant_bot?.admin !== null ? true : false
const isAdmin = participant_sender?.admin !== null ? true : false
const { runtime, getRandom, getTime, tanggal, toRupiah, telegraPh, pinterest, ucapan, generateProfilePicture, getBuffer, fetchJson } = require('./all/function.js')
const contacts = JSON.parse(fs.readFileSync("./all/database/contacts.json"))


if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(namabot), color(`[ PESAN ]`, `blue`), color(`FROM`, `blue`), color(`${senderNumber}`, `blue`), color(`Text :`, `blue`), color(`${cmd}`, `white`))
}

{
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/Eh3gfYMWEQmAPYgIDqT7pE` + await Skyzo.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Skyzo.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} *ANTILINK ENABLED*`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://t1.pixhost.to/thumbs/5378/593401890_20250424_141012.jpg", title: "> LINK GRUP DETECTED", previewType: "PHOTO"}}}, {quoted: m})
await Skyzo.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await Skyzo.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}}

{
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/Eh3gfYMWEQmAPYgIDqT7pE` + await Skyzo.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Skyzo.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} *ANTILINK ENABLED*`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://t1.pixhost.to/thumbs/5378/593401890_20250424_141012.jpg", title: "> LINK GRUP DETECTED", previewType: "PHOTO"}}}, {quoted: m})
await Skyzo.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
}
}}

const qdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: 'BOT WA ©FAA STORE',jpegThumbnail: ""}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `BOT WA ©FAA STORE`,jpegThumbnail: ""}}}

const qloc2 = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `BOT WA ©FAA STORE`,jpegThumbnail: ""}}}

let example = (teks) => {
return `\n*Contoh Penggunaan :*\nketik *${cmd}* ${teks}\n`
}

var resize = async (image, width, height) => {
let oyy = await Jimp.read(image)
let kiyomasa = await oyy.resize(width, height).getBufferAsync(Jimp.MIME_JPEG)
return kiyomasa
}

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const qbug = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {listResponseMessage: {title: `FAA STORE`
}}}

const MessageBug = async (target) => {
return Skyzo.sendMessage(target, {document: fs.readFileSync("./all/kosong.js"), mimetype: "😄😇😂🔥", fileName: "Paket.zip", fileLength: 99999999999, caption: `key.com${teksbug2}`}, {quoted: qbug})
}

switch (command) {

case "faa": case "faa": {
const textnya = `*_SIMPLE PUSHKON BY FAA_*
> Mode ${Skyzo.public ? "Public" : "Self"}

*#MENU*

.public
.self
.pushkontak
.listgc
.owner

> ©FAA STORE
> BUY NO ENC CUMA 3K CHAT
> wa.me/6283856752850
> wa.me/6287758921793
`
Skyzo.sendMessage(m.chat, {text: textnya, contextInfo: {mentionedJid: [m.sender], externalAdReply: {showAdAttribution: true, thumbnailUrl: global.image, title: `© ${global.namabot}`, body: null, sourceUrl: linkgc, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: qdoc})
}
break
case "menu": {
m.reply ('menu? ketik .faa')
}
break
case "public": {
if (!isOwner) return m.reply(msg.owner)
Skyzo.public = true
m.reply("done, mode : public")
}
break
case "self": {
if (!isOwner) return m.reply(msg.owner)
Skyzo.public = false
m.reply("done, mode : self")
}
break
case "owner": {
Skyzo.sendContact(m.chat, [owner], "OWNER BOT", m)
}
break
case "pushkontak": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return m.reply("Contoh :\n.pushkontak idgc|jeda|pesan\n\nNote : Jeda 1 detik = 1000\nketik .listgc untuk melihat semua list id grup")
if (!text.split("|")) return m.reply("Contoh :\n.pushkontak idgc|jeda|pesan\n\nNote : Jeda 1 detik = 1000\nketik .listgc untuk melihat semua list id grup")
var idnya = text.split("|")[0]
var delay = Number(text.split("|")[1])
var teks = text.split("|")[2]
if (!idnya.endsWith("@g.us")) return m.reply("Format ID Grup Tidak Valid")
if (isNaN(delay)) return m.reply("Format Delay Tidak Valid")
if (!teks) return m.reply("Contoh :\n.pushkontak idgc|jeda|pesan\n\nNote : Jeda 1 detik = 1000\nketik .listgc untuk melihat semua list id grup")
var groupMetadataa
try {
groupMetadataa = await Skyzo.groupMetadata(`${idnya}`)
} catch (e) {
return m.reply("ID Grup tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
m.reply(`Memproses Mengirim Pesan Ke ${halls.length} Member Grup`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
await Skyzo.sendMessage(mem, {text: teks}, {quoted: qloc2})
await sleep(Number(delay))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`Berhasil Mengirim Pesan Ke ${halls.length} Member Grup, File Contact Berhasil Dikirim ke Private Chat`)
await Skyzo.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./all/database/contacts.vcf", "")
}}
break
case "listgc": case "cekid": case"listgrup": {
let gcall = Object.values(await Skyzo.groupFetchAllParticipating().catch(_=> null))
let listgc = `LIST ALL CHAT GRUP\n\n`
await gcall.forEach((u, i) => {
listgc += `#Nama : ${u.subject}\n #ID : ${u.id}\n#Total Member : ${u.participants.length} Member\n#Status Grup :${u.announce == true ? "Tertutup" : "Terbuka"}\n#Pembuat :${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
m.reply(listgc)
}
break
default:
if (budy.startsWith('$')) {
if (!isOwner) return
exec(budy.slice(2), (err, stdout) => {
if(err) return Skyzo.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return Skyzo.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

if (budy.startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
Skyzo.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
Skyzo.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

if (budy.startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return Skyzo.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return Skyzo.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

}} catch (e) {
console.log(e)
Skyzo.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})